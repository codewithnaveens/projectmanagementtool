<?php
session_start();
include('../include/connection.php');
if(isset($_POST['assign_task'])){
    $query="insert into tasks values(null, $_POST[id],'$_POST[description]','$_POST[start_date]','$_POST[end_date]','Not started')";
    $query_run=mysqli_query($conn,$query);
    if($query_run){
        echo "<script type='text/javascript'>
        alert('task created successfully...');
    window.location.href='admin_dashboard.php';
    </script>
    ";
        
    }
    else
    {
        echo "<script type='text/javascript'>
        alert('Error...plz try again.');
    window.location.href='admin_dashboard.php';
    </script>
    ";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin dashboard</title>
    <!--jquery file  -->
    <script src="../include/jquery.min.js"></script>
  

    <!-- bootstrap file -->
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <script type="text/javascript">
    $(document).ready(function() {
        $('#assign_task').click(function() {
            $("#right_sidebar").load("assign_task.php");
            
        });

    });
    $(document).ready(function() {
        $('#manage_task').click(function() {
            $("#right_sidebar").load("manage_task.php");
            
        });

    });
    </script>
</head>

<body style="background-color:white;">
    <!-- header code start -->
    <div class="row" id="header">
        <div class="col-md-12">
            <div class="col-md-4" style="display:inline-block;">
                <h3>Project Management Tool</h3>
            </div>
            <div class="col-md-6" style="display:inline-block; text-align:right;">
                <b>Email:</b><?php  echo $_SESSION['email'];?>
                <span style="margin-left:25px;"><b>Name:</b><?php echo $_SESSION['name']; ?></span>
            </div>
        </div>

    </div>
    <div class="row">
        <div class="col-md-2" id="left_sidebar">
            <table class="table">
                <tr>
                    <td style="text-align:center;">
                        <a href="admin_dashboard.php"  class="logout_link" style="color:white ;">Dashboard</a>
                    </td>
                </tr>
                <tr>
                    <td style="text-align:center;">
                        <a href="#" class="logout_link" id="assign_task"  style="color:white ;">Assign Task</a>
                    </td>
                </tr>
                <tr>
                    <td style="text-align:center;">
                        <a href="#"  class="logout_link" id="manage_task"  style="color:white ;">Manage Task</a>
                    </td>
                </tr>
              
                <tr>
                    <td style="text-align:center;">
                        <a href="../logout.php"  class="logout_link"  style="color:white ;">logout</a>
                    </td>
                </tr>

            </table>

        </div>
        <div class="col-md-10" id="right_sidebar">
        <div class="col-md-5 col-sm-offset-4 frame">
            <ul></ul>
            <div>
                <div class="msj-rta macro" style="margin:auto">                        
                    <div class="text text-r" style="background:whitesmoke !important">
                        <input class="mytext" placeholder="Type a message"/>
                    </div> 
                </div>
            </div>
        </div>      

        </div>

        </div>
    </div>
</body>

</html>
<script type=text/javascript>
var me = {};

var you = {};

function formatAMPM(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0'+minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
}            

//-- No use time. It is a javaScript effect.
function insertChat(who, text, time = 0){
    var control = "";
    var date = formatAMPM(new Date());
    
    if (who == "me"){
        
        control = '<li style="width:100%">' +
                        '<div class="msj macro">' +
                            '<div class="text text-l">' +
                                '<p>'+ text +'</p>' +
                                '<p><small>'+date+'</small></p>' +
                            '</div>' +
                        '</div>' +
                    '</li>';                    
    }else{
        control = '<li style="width:100%;">' +
                        '<div class="msj-rta macro">' +
                            '<div class="text text-r">' +
                                '<p>'+text+'</p>' +
                                '<p><small>'+date+'</small></p>' +
                            '</div>' +
                        '<div class="avatar" style="padding:0px 0px 0px 10px !important"></div>' +                                
                  '</li>';
    }
    setTimeout(
        function(){                        
            $("ul").append(control);

        }, time);
    
}

function resetChat(){
    $("ul").empty();
}

$(".mytext").on("keyup", function(e){
    if (e.which == 13){
        var text = $(this).val();
        if (text !== ""){
            insertChat("me", text);              
            $(this).val('');
        }
    }
});

//-- Clear Chat
resetChat();

//-- Print Messages
insertChat("me", "Hello sir", 0);  
insertChat("you", "Hello, ", 1500);
insertChat("me", "i have completed the task sir !", 3500);
insertChat("you", "good , your report forwarded",7000);
insertChat("me", "thank you sir", 9500);
insertChat("you", " :)", 12000);

 </script>