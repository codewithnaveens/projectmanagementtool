<?php
$conn=mysqli_connect("localhost:3307","root"," ");
$db=mysqli_select_db($conn,"pmt_db");


?>